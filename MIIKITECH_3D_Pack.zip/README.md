
# MIIKITECH 3D – L'expertise en électricité

Logiciel de dessin électrique 2D/3D pour usage **domestique et industriel** uniquement.
Aucune fonction pour architecture, plomberie ou soudure.

## Mot de passe d'accès au logiciel
**Douze2001@**

## Fonctionnalités principales
- Dessin de plans électriques (usines, maisons, tableaux, armoires)
- Symboles électriques industriels uniquement
- Animation en temps réel
- Suivi technique live (salle électrique, tableau maison)

## Slogan
**Miikitech – L'expertise en électricité**

## OS Supporté
Windows 10/11 – 64 bits uniquement

---
> Tout usage non autorisé est interdit. Logiciel protégé.
